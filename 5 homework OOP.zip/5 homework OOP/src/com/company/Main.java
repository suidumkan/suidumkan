package com.company;

public class Main {

    public static void main(String[] args) {
        Boss boss = new Boss();
boss. setDamage(50);
boss.setDefenceType(97);
boss.setHeath(150);
        System.out.println(boss.getDamage() + " " + boss.getDefenceType() + " " + boss.getHeath());
    }
}
